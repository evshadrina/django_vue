from django import forms
from .models import Feedback
from django.forms.widgets import NumberInput
''''
class FeedbackForm(forms.Form):
    name=forms.CharField(label='Имя', max_length=7, min_length=2, error_messages={
        'max_length': 'Слишклм длтинное имя',
        'min_length':' Сдишком коротнлое имя',
        'required': 'Укажите хотя б 2 символа'

    })
    surname = forms.CharField()
    feedback = forms.CharField(widget=forms.Textarea(attrs={'rows':2, 'cols':20}))

'''



class FeedbackForm(forms.ModelForm):

    class Meta:
        model = Feedback
        fields ='__all__'
        #fields = ('title', 'text',)
        labels={
            'name': 'Имя',
            'surname': 'Фамилия',
            'feedback': 'Отзыв',
            'mark':'оценка'
        }
        widgets={
            'mark': NumberInput(attrs={'min':1, 'max':10})
        }